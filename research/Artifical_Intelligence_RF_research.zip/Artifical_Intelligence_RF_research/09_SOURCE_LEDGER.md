# Source ledger — factual support, status, limits, and verification trail

**Review date:** 2026-11-22. Links inspected from public websites (S-prefix) or owner-connected GitHub repository content (P-prefix). Where a file changes, re-pin its commit SHA before treating claims as historically exact.

| ID | Type | Evidence used | Source URL | Important limitation |
|---|---|---|---|---|
| S01 | PUBLISHED_SOURCE | Haq et al., *AI-Enhanced FPGA-Based Software Defined Radio for Real-Time Spectrum Sensing and Adaptive Jamming Mitigation*, 2026-10-19; reported PYNQ-Z2 FFT/QNN, 2.1ms, 94.5%@5dB, 96.3%@FPR .05, 1.8mJ; discussion of OOD and field limits | https://link.springer.com/article/10.1007/s11265-026-02026-4 | Authors' experiments, not independently reproduced or deployed on OrcPluto. |
| S02 | PUBLISHED_SOURCE | TorchSig generator, transforms, pretrained-model ecosystem | https://torchsig.com/ | Tool describes capabilities, not independently established classifier quality. |
| S03 | PUBLISHED_SOURCE | FINN Vivado IPI IP generation, retired PYNQ-Z1/Z2 turnkey support | https://finn.readthedocs.io/en/latest/getting_started.html | Custom Fishball integration necessary. |
| S04 | PUBLISHED_SOURCE | Official ESP-DL supports ESP32-P4 model quantization/inference | https://docs.espressif.com/projects/esp-dl/en/latest/getting_started/readme.html | A valid target chip does not imply an RF use case performance guarantee. |
| S05 | PUBLISHED_SOURCE | ESP-VISION documents ESP-DL and TFLite Micro model runtime paths | https://docs.espressif.com/projects/esp-vision/en/latest/esp32p4/concepts/ai-inference.html | Runtime ecosystem may vary with version and build. |
| S06 | PUBLISHED_SOURCE | 2025 TorchSig 2.0 GRCon presentation on generator/impairment research | https://events.gnuradio.org/event/26/contributions/752/attachments/220/586/TorchSig_GRCon2025.pdf | Reference to workshop, not reproduced in this package. |
| S07 | PUBLISHED_SOURCE | hls4ml FPGA ML conversion and synthesis setup | https://fastmachinelearning.org/hls4ml/intro/setup.html | Requires matching synthesis toolchain and target support. |
| S08 | PUBLISHED_SOURCE | AMD XC7Z020/Zynq-7000 family overview resource limits | https://www.amd.com/content/dam/xilinx/support/documents/data_sheets/ds190-Zynq-7000-Overview.pdf | Totals, not placed/routed free resources. |
| S09 | PUBLISHED_SOURCE | Adaptive frequency-domain CFAR spectrum sensing research (2026) | https://pubmed.ncbi.nlm.nih.gov/42045497/ | Not evidence of our detector's results. |
| S10 | PUBLISHED_SOURCE | TorchSig code's MIT license statement | https://github.com/TorchDSP/torchsig/blob/main/LICENSE.md | Code license is not universal license of every dataset/weight. |
| S11 | PUBLISHED_SOURCE | Official SigMF metadata and annotations specification | https://sigmf.org/ | Record exact spec version on implementation. |
| S12 | PUBLISHED_SOURCE | DeepSig historical data licensing, CC BY-NC-SA 4.0 | https://www.deepsig.ai/datasets/ | Noncommercial dataset terms; legal review for commercial use. |
| P01 | PROJECT_RECORDED | OrcPluto `PROJECT_TRUTH.md` repository boundaries and P0–P7 stages | https://github.com/hardcoreerik/OrcPluto-Firmware/blob/integration/agent2-edge-ai-roadmap-20261121/PROJECT_TRUTH.md | Snapshot on 2026-11-21; refer to status before use. |
| P02 | PROJECT_RECORDED | OrcPluto `EDGE_AI_INTEGRATION.md`: single-owner, IQ continuity, NDJSON measurement, no-drop-or-hide design | https://github.com/hardcoreerik/OrcPluto-Firmware/blob/integration/agent2-edge-ai-roadmap-20261121/docs/architecture/EDGE_AI_INTEGRATION.md | Contract is integration design; FPGA AI path still proposed. |
| P03 | PROJECT_RECORDED | Offline C++17 detector, 11 host assertions and sanitizer log summary | https://github.com/hardcoreerik/OrcPluto-Firmware/blob/integration/agent2-edge-ai-roadmap-20261121/experiments/edge-detector/OFFTARGET_TEST_EVIDENCE.md | Off-target only, not target classifier or streaming benchmark. |
| P04 | PROJECT_RECORDED | Independent Fishball XC7Z020/AD9361 investigation / exact-board remaining uncertainties | https://github.com/hardcoreerik/REA-Results/blob/research/orcpluto-fishball-hardware-20261121/RESEARCH.md | External/third-party board data; not owner-device measurement. |
| P05 | PROJECT_RECORDED | OrcPluto Agent 2 FPGA acceleration study, timing and resource limitations | https://github.com/hardcoreerik/OrcPluto-Firmware/blob/integration/agent2-edge-ai-roadmap-20261121/research/agent2/FPGA_AI_ACCELERATION_STUDY.md | Public reported synthesis; do not add incompatible build numbers. |
| P06 | PROJECT_RECORDED | OrcPluto protocol-aware classification dataset and abstention research | https://github.com/hardcoreerik/OrcPluto-Firmware/blob/integration/agent2-edge-ai-roadmap-20261121/research/agent2/SIGNAL_CLASSIFICATION_RESEARCH.md | Research only, no trained model. |

## Confidence boundaries
**High** that the URLs above are real sources and they publish the cited concepts. **Lower** certainty that all reported figures transfer to different hardware, unknown conditions or different model architectures. No raw datasets were downloaded/independently tested; no original author's raw measurements were recalculated; no on-target code ran in this session. Report only as attributed claims.

## Recheck list for another agent
1. Fetch the *latest exact original paper* and its supplemental material; verify model classes, training/test splits, hardware power method, latency definition and OTA conditions.
2. Pin author-provided source (if any) and independently reproduce off-target labels before claiming replication.
3. Read the branch's current project truth; don't silently substitute main as the evidence source.
4. Verify license versions, board revision, complete clock domains and post-route timing before claiming hardware feasibility.
