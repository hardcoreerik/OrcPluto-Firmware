# Related work, reusable tools, and responsible data use

## Adjacent concepts / avoid unverified novelty claims
- Statistical energy detection and adaptive thresholding predate this work; CFAR-inspired spectral thresholds are an important non-AI control. A contemporary paper treats adaptive frequency-domain CFAR under jamming [S09].
- RFML modulation recognition, anomaly/OOD detection, recurrent signal patterns, spectrogram object detection, and embedded FPGA inference are established research areas [S01][S02][S03][S06]. The differentiator must be a reproducible cross-hardware product/measurement pipeline, not a blanket “first AI SDR.”
- Conventional feature extraction can beat a much larger net when labels are scarce or badly transferred between real receivers. Require explicit ablation tests, not opinions.

## Source ecosystem
| Source | Directly supported capability | Reuse note |
|---|---|---|
| Haq et al., 2026 [S01] | FPGA FFT → log-power → QNN spectrum sensing and interference study | Citation only; verify full methodology, no automatic code/weight grant. |
| TorchSig [S02][S10] | PyTorch datasets, impairments, synthetic modulations | Project reports MIT code license; review separately generated dataset/model asset rights. |
| FINN [S03] | Quantized neural network to FPGA dataflow IP | Check toolchain and license; PYNQ-Z2 is not official turnkey target now. |
| hls4ml [S07] | Neural-to-HLS conversion for selected architectures | Test toolchain; no Fishball drop-in design. |
| ESP-DL [S04][S05] | ESP32-P4 quantized inference mechanisms | Software support ≠ tested RF throughput. |
| SigMF [S11] | standardized IQ capture data + metadata + annotations | Use capture metadata, not undocumented free-form date/sample assumptions. |
| DeepSig datasets [S12] | historical AMC examples | DeepSig states CC BY-NC-SA 4.0 and discourages their use for new practical projects; rights review for commercialization. |
| Existing OrcPluto edge-detector [P02][P03] | off-target fixture and logging baseline | Respect original project architecture, source hashes and validity limits. |

## Licensing, provenance and data governance
No third-party paper PDF, third-party code, pretrained weights, IQ recordings or generated training data are distributed in this ZIP. Bibliographic summaries and primary URLs only. Do not conflate an MIT library license with rights in *every dataset or model weight* loaded through it. Any commercial distribution should record origin, dataset license, permission/collection basis, training manifest, model source/weights license, redistribution scope, privacy, retention and a human rights review for ambiguity.

## Dataset validation principles
- Synthetic signals are useful for controlled defect injection, not proof of generalization to real outdoor interference.
- Separate training and test by **recording, day, device, antenna, site and generator**, not randomly by adjacent FFT frame.
- Include unknown classes, negative cases, receiver faults, empty bands, overlapping signals and bad metadata.
- Report false alarms and missed events under varying thresholds and sample-time validity.
- Handle private receptions conservatively. Event-only analytics are preferable to indefinite retention of raw payloads.

## Safety boundaries
Receive-first, no active on-air jamming, interference generation or automatic transmitter retuning. Controlled synthetic IQ mixtures and properly isolated bench fixtures suffice to test early anomaly detection. Anomaly or modulation “candidate” must not imply sender identity, intent, secrecy, or a successful decode.
