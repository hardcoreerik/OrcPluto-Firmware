# Executive assessment — pursue explainable spectrum memory before full FPGA neural inference

## One-paragraph takeaway
The paper by Haq et al. demonstrates a reported *design* for an FPGA-resident FFT → log-power features → quantized neural-network chain on PYNQ-Z2/Zynq-7020 [S01]. Its reported 2.1 ms latency and 94.5% 5 dB SNR classification accuracy are not OrcPluto benchmarks. **OrcPluto's fastest defensible differentiation is an explainable, history-aware RF observation service that learns the normal environment and checks model decisions against real RF features and decoder evidence, while preserving unmodified IIO/iiod IQ acquisition.** A validated ARM model should precede any expensive PL QNN port. No changes to OrcSDR are proposed in this package.

## Priority decision
**P0: prove value, not novelty.** Reuse the existing off-target detector and internal measurement contract recorded in `OrcPluto-Firmware` [P01–P03]. Compare an adaptive baseline against a deliberately simple fixed threshold and frequency-neighborhood adaptive threshold. If it cannot improve false alarms and event recall on held-out recordings, do not promote it as AI.

**P1: the distinctive OrcSense improvement.** Add *context keys* (RF center/rate, receiver/gain state, antenna/band, time validity, optional site identifier), a *normal-state memory* (per-bin median/spread and short-term burst characteristics), and an *explanation record* (“observed peak above established baseline; AGC/gain change detected”). Model-generated probabilities are not calibrated signal-power measurements.

**P2: temporal fingerprints.** Summarize bursts and frequency movement over multiple windows. Novel combination: time-aware fingerprints PLUS protocol/CRC evidence PLUS receiver-quality counters. An identified pattern is not a transmitter identity, and “unusual” is not “hostile jamming.”

**P3: conditional closed-loop recommendations.** Candidate gain/filter/scan changes should first be replayed against fixed IQ fixtures and verified for packet recovery, SNR proxies, or other stated objective. Suggest or log choices first, never retune a shared IQ source unsafely. An AGC decision should not be benchmarked against the same moving RF scene without controls.

**P4: FPGA acceleration only with need shown.** Start with passive counters/power/feature FIFO; if the ARM/host branch demonstrably limits a requested feature rate, investigate FFT/feature IP and later INT8/INT4 inference. Current FINN board support requires custom integration for Zynq-7000 [S03].

## Proposed product differentiators (hypotheses, not patent/prior-art conclusions)
1. *Contextual RF memory*: receiver and environmental conditions explicitly key the baseline; avoid learning the wrong noise floor when gain changes.
2. *Explainability that cites sensor evidence*: each anomaly carries features, thresholds, quality flags and unambiguous unknown/uncertain labels.
3. *Receiver-health-aware intelligence*: discriminate local clipping, DC spikes, USB/sample losses and gain transitions from likely external RF phenomena.
4. *Protocol-verified feedback*: measure improvement in actual decode success where supported, not only neural softmax scores.
5. *Cross-target reproducibility*: same JSON fixtures and evaluation metrics on host reference, Zynq ARM, and optional PL side-channel.
6. *Evidence-first cooperative events*: share compact fingerprints and confidence provenance; no permanent OrcStream wire assignment until protocol owner defines it.

## Go/no-go
GO for an offline research prototype and schema/fixture work. NO-GO for claims of real jammer mitigation, active adaptive tuning, continuous FPGA inference, production-grade classifier accuracy or device-specific power numbers until measured on the exact board.

References: [S01] [S02] [S03] [S04] [S05] [P01] [P02] [P03], expanded in `09_SOURCE_LEDGER.md`.
