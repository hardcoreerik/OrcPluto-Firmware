# Open questions / explicit risk register

| ID | Question / risk | Current status | Evidence needed to close |
|---|---|---|---|
| R01 | Exact owner's Fishball R1/AD9361 revision and RX paths unverified | BLOCKED | On-unit read-only inventory, part markings, kernel/IIO data with redacted identifiers. |
| R02 | Inference paper reports 94.5% on its class/SNR mix; can unseen sites reproduce? | UNKNOWN | Independent capture-group-held-out accuracy, confusion matrix, open-set evaluation. |
| R03 | Does adaptive memory learn away persistent interference? | PROPOSED | Synthetic persistent interferer, short/long baseline isolation and recovery curves. |
| R04 | Can health signals explain anomalies, without inventing causal certainty? | PROPOSED | Ground-truth DC/clipping/gain/drop fault injection; explanation precision tests. |
| R05 | Can classification run without starving original IIO IQ? | BLOCKED | Source arbitration design, overload/failure tests, source vs feature loss counts. |
| R06 | Are there FPGA timing/BRAM/clock-domain margins? | BLOCKED | Exact HDL+Vivado version synthesis/post-route WNS, CDC, utilization, RX continuity. |
| R07 | Is ARMv7 INT8 model runtime viable for exact Linux image? | BLOCKED | Cross-compile, run on target, CPU/PSS/latency p50/p95/p99 and energy instrumentation. |
| R08 | Which radio events have independent ground truth and acceptable recording rights? | OPEN | Capture consent/provenance, annotation procedure, controlled source fixtures, licenses. |
| R09 | Is anomaly data useful enough to users to justify UI/transport complexity? | PROPOSED | Usability pilot with side-by-side logs, feedback against actionable events. |
| R10 | How will signal-event data map into OrcStream without inventing wire semantics? | BLOCKED | OrcStream protocol-owned stable EVENT schema and conformance tests. |
| R11 | Does low-power model produce an advantage over low-cost CFAR/statistics? | UNKNOWN | Matched ablation and calibration with measured power/latency. |
| R12 | Can monitoring times be compared across nodes? | BLOCKED | Verified clock anchors and uncertainty model, otherwise relative-only comparison. |

## Decision policy
On an unknown fact, record `unknown`, not a confident guess. A missing sensor field is `not_measured`, not zero. Before declaring real-time accuracy, report full distribution including 95th/99th percentile and rare events, rather than a single mean. Before declaring anti-jamming, demonstrate **mitigation** against objective reception quality, not just classification. Reuse existing OrcPluto development branches and do not touch OrcSDR.
