# Safe, staged OrcPluto edge-intelligence architecture

## Existing project boundaries (snapshot 2026-11-21)
`hardcoreerik/OrcPluto-Firmware` active integration branch `integration/agent2-edge-ai-roadmap-20261121` already records a non-production C++17 offline CS16LE energy/DFT detector, 11 host assertions, synthetic test fixture, and `orcp.internal.measurement.v0` experimental NDJSON event concept [P01][P02][P03]. The detector is **off-target correctness evidence only**, not a real-time benchmark. Use it as an input fixture and compatibility baseline; don't duplicate it in this report archive.

## Proposed progression (not implemented by this package)
```text
AD9361 receiver -> existing vendor-compatible RX path -> IIO/iiod original CS16 IQ
                                                  |
                               authorized single-owner IQ tap (CPU prototype)
                                                  |
                         bounded window feature calculator, sample epoch/quality
                                                  |
                   noise/reference memory + DSP detector / optional tiny model
                                                  |
                         evidence + explanation + unknown candidate labels
                                                  |
                        internal NDJSON event history / optional clipped IQ
                                                  |
                future OrcStream EVENT adapter (only when protocol is defined)

Optional future PL mirror (after resource, timing, CDC and original-IQ validation):
 RX valid samples -> nonblocking feature tap -> feature FIFO -> ARM event service
```

No second independent IIO DMA owner unless its coexistence is **verified**, not assumed. Raw source IQ wins priority; optional classification drops features with counters rather than stalling RX. Restore existing native 12-bit signed values in 16-bit containers and preserve original IIO behavior. A 64-bit sample counter is not UTC without timebase linkage and uncertainty [P01][P02].

## Three runtime tiers sharing a feature contract
**Tier A / offline reference:** replay saved signed little-endian complex 16-bit IQ; single-thread correctness first; record exactly window, FFT normalization, bin order and sample-index bounds.
**Tier B / Zynq Cortex-A9:** lightweight feature detector using existing Linux acquisition ownership. Run on a bounded queue at a lower cadence than raw sample rate; benchmark worst-case CPU/PSS/tail latency. Model candidate only after CPU baseline passes.
**Tier C / PL accelerator:** low-risk power/threshold/spectral features on the no-backpressure mirror; fixed-point golden vectors then timing and full live IIO regression; FINN/HLS neural IP only when demonstrated need remains.

## Proposed extension of local measurements (NOT a frozen OrcStream schema)
```
source_id, source_epoch, receiver_channel, first_sample_index, sample_count,
sample_timebase, center_freq_hz, sample_rate_hz, gain_db_or_unknown,
rf_config_epoch, window_id, bin_width_hz, power_units, normalization_id,
noise_estimate, noise_spread, occupied_bandwidth_hz, burst_duration_samples,
observed_spectral_delta, clipping_count, dc_artifact_score,
iq_loss_status, feature_drops, classification_skips,
anomaly_rule_id, anomaly_score, decision_basis, decision_kind,
model_id_or_none, calibration_state, confidence_or_null,
evidence_ref_or_none, loss_flags, timestamp_uncertainty_or_null
```

Each field must carry explicit units and unavailable statuses; power in dBFS is not dBm. A `0..100` anomaly score is a relative decision statistic, not a calibrated probability. A modulation candidate requires calibrated evaluation; a validated protocol requires actual decoding evidence. Unknown is always valid.

## Normal-environment memory state
- Key by center-frequency range, bandwidth/rate, tuner gain profile, analog/digital filter configuration, antenna path, source model, source epoch. Optional site key with privacy and retention rules.
- Use short-term vs long-term robust medians/spreads; maintain seen-sample count and age. Explicit warm-up.
- Freeze or downweight adaptation around candidate anomalies, calibration changes and AGC transitions to prevent poisoning.
- Reset or fork baseline after retunes/gain/rate changes; log baseline revisions and reasons.
- Cache small statistical state only, not raw IQ by default. Retain bounded snapshots on explicit trigger and storage permission.

## UI/product implications (no UI code authored)
Event list: measured properties, likely competing explanations, evidence status, raw IQ availability, configuration and sample-time basis. Avoid a “JAMMER DETECTED” badge based on energy alone. More useful copy: “New intermittent 19 kHz-wide signal; 6.4 sigma above same-setting baseline; clipping not measured; source unknown.” Example values are illustrative, not empirical.

## Cross-project ownership
OrcPluto firmware owns local acquisition, safe receiver operation, hardware-classification runtime and evidence production. OrcStream owns its neutral EVENT/wire contracts and conformance. REA-Results preserves report/provenance. RSA-Sandbox remains local, with imported-source or executable audits deferred to authorized owner workstation. OrcSDR is intentionally not modified in this research handoff.
