# Artificial Intelligence for RF Intelligence — Research and Brainstorming Package

**Prepared:** 2026-11-22  |  **Working title:** OrcSense / AI RF Spectrum Intelligence
**Status:** research, architecture hypotheses, and test plans; **not** deployed firmware
**Intended repositories:** `hardcoreerik/OrcPluto-Firmware` (active edge-AI integration branch) and `hardcoreerik/REA-Results` (independent permanent research branch). **OrcSDR excluded by request.**

## Purpose
A documented exploration of accessible, measurable ways to extend the 2026 Haq et al. FPGA/SDR paper into useful receive-side spectrum intelligence: environment-adaptive detection, RF-event fingerprints, receiver-fault discrimination, evidence-driven adaptation, portable model execution and cautious FPGA acceleration.

## Start here
1. `01_EXECUTIVE_ASSESSMENT.md` — conclusion, priority, immediate opportunity.
2. `02_ORIGINAL_PAPER_EVIDENCE.md` — what the paper actually reports and does *not* prove.
3. `03_BRAINSTORMING_WORKSHOP.md` — twelve ideas, product tweaks, comparison matrix.
4. `04_ORCPLUTO_INTEGRATION_ARCHITECTURE.md` — safe hardware/software flow, execution tiers, event semantics.
5. `05_EXPERIMENT_AND_VALIDATION_PLAN.md` — reproducible experiments, baselines, test splits, acceptance gates.
6. `06_HARDWARE_AND_TOOLCHAIN_FEASIBILITY.md` — Zynq-7020, ESP32-P4 feasibility and limitations.
7. `07_PRIOR_ART_DATA_AND_RIGHTS.md` — references, datasets, reuse/licensing concerns.
8. `08_HANDOFF_TO_MAIN_SESSION.md` — integration guidance for another engineering session.
9. `09_SOURCE_LEDGER.md` — claim-level evidence and authoritative URLs.
10. `10_OPEN_QUESTIONS_AND_RISKS.md` — unresolved dependencies.
11. `EXPERIMENT_MATRIX.csv` — proposed experiments with metrics and blockers.
12. `manifest.json` — included artifact hashes, not a hardware benchmark result.

## Evidence grades
- **PUBLISHED_SOURCE:** independently accessible publication/vendor documentation, not reproduced by us.
- **PROJECT_RECORDED:** statement from a project repository's own documentation; inherits its own validation limits.
- **PROPOSED:** novel hypothesis, design choice, or future validation step; not an achieved result.
- **NOT_TESTED:** no relevant measurement in this research session.

## Deliberate exclusions
No firmware changes, bitstreams, model weights, captures, device flashes, operational jamming, RF transmissions, actual board measurements, or proprietary source are included. There is **no claimed AI accuracy or latency for OrcPluto**. `RSA-Sandbox` is documented as a local-only lab and must not be remotely pushed as part of this handoff.
