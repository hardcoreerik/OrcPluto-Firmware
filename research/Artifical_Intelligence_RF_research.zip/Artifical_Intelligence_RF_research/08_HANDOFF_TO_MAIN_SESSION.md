# Main-session research handoff and integration prompt

**Read first:** `README.md`, `09_SOURCE_LEDGER.md`, and the OrcPluto branch's own `PROJECT_TRUTH.md`. This archive is research evidence and workshop output, not a deployed implementation.

## Assignment (copy/paste to an implementation agent)
> You are the OrcPluto AI/RF research integration lead. The owner approved this research preparation and publication in the research repositories, **not** arbitrary firmware flashing, TX operation, hardware boot modification or changing OrcSDR. Read `Artifical_Intelligence_RF_research.zip` completely. Start from `hardcoreerik/OrcPluto-Firmware` branch `integration/agent2-edge-ai-roadmap-20261121`, respecting `PROJECT_TRUTH.md`, `ROADMAP.md`, `research/agent2/*`, and `docs/architecture/EDGE_AI_INTEGRATION.md`. Evaluate the existing off-target detector, and propose an incremental host-only `Spectrum Memory` experiment alongside fixed-threshold and CFAR-like controls. Keep original IIO native IQ lossless and authorized acquisition single-owned. Model decisions must distinguish measurement, morphology, candidate classification, validated protocol, unknown and receptor artifact. Do not invent OrcStream packet IDs. Produce pinned reproducible fixtures, logs saved in the process launch directory, group-held-out metrics, side-by-side confusion matrices, and documented blockers. Only escalate to ARM target or FPGA if a measured result justifies it and target-specific authorization/recovery requirements are met. **Do not modify or push `hardcoreerik/OrcSDR`. Do not push `RSA-Sandbox`; it is local-only under its documented rules.** Commit any authorized firmware work to an appropriate scoped non-main branch, never silently merge. Update research evidence in the appropriate documentation branch without altering generated REA indexes.

## Proposed first engineering issue
**Title:** Offline time-aware RF anomaly baseline and receiver-health disambiguation
**Deliverables:** feature JSON schema with units/timebase; deterministic replay fixtures (noise, pulses, sweep, clipping, DC, retune, drop); reference B0/B1/A1 detectors; grouped evaluation report; performance instrumentation; non-regression checks for the C++17 detector; no FPGA build or UI changes.

**Acceptance:** deterministic tests and independent ground truth; false-alarm and recall by condition; no source-IQ mutation; complete measurement/proposed distinction; new test logs in launch directory; concise evidence in research docs. Target classification and deployment are deferred.

## Follow-on tracks
1. Source-quality and holdout corpus curation (SigMF + hashes), with permissions and licensing check.
2. ARMv7hflite model feasibility after baseline wins in host replay (actual ELF and p99, not hypothetical).
3. Hardware RX path side-tap proof after original image backup/recovery and independently verified exact-board FPGA resource timing.
4. OrcStream event adapter *only* following finalized generic event semantics; protocol/codec remains in OrcStream.

## Repository delivery policy
- **OrcPluto-Firmware:** research/ archive on `integration/agent2-edge-ai-roadmap-20261121`; no firmware source or root roadmap modifications in this package.
- **REA-Results:** an independent permanent research branch with `RESEARCH.md` and identical archive under `research/`; no merge into main, no editing generated `INDEX.md`/`index.json`/`graph.json`.
- **RSA-Sandbox:** local-only, no remote push; may be imported locally on an owner machine through its normal tooling.
- **OrcSDR:** excluded completely.
