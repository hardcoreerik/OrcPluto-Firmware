# Reproducible tests and required acceptance evidence

**No experiments described below were executed in this research package.** The prior OrcPluto project's synthetic C++17 detector test is documented separately as `REPRODUCED_OFF_TARGET` [P03]. Metrics and numeric targets below are **proposals**, not actual performance.

## Experiment A — adaptive baseline versus classical detectors (first)
**Question:** Does context-aware spectrum memory detect intermittent changes with fewer false positives than fixed power threshold and robust local-frequency CFAR across unseen recording sessions?

**Inputs:** (a) synthetic complex IQ (tone, weak burst, narrowband, wideband, swept carrier, periodic pulse, pure noise, DC spike, clipped input, gain transition, sample discontinuity); (b) optional consented signed-CS16 AD9361 captures *only after source/power/recovery checks*. Freeze known random seeds and save content hashes.

**Comparators:** B0 simple calibrated fixed threshold; B1 local frequency-neighbor adaptive threshold (CFAR-inspired [S09]); A1 time-and-context median+MAD with hysteresis. Equal time/frequency budgets and identical source windows. Classifier only receives features present in every comparator or explicitly declared.

**Ground truth:** generator log or independently annotated known emissions, not model output. Distinguish anomalous RF events from receiver artifacts and unknown origin.

**Metrics:** event recall/precision, detection latency in samples and ms if sample clock verified, false alarms per hour *and* per event opportunity, ROC/PR curves, time-to-detect, missed brief bursts, storage/memory, feature cost, confidence intervals per recording group. Evaluate baseline contamination, cold start, AGC/gain changes, retune and drift.

**Splits:** no adjacent windows from a continuous recording in train and test. Hold out whole days, physical receivers, antenna configurations, gain modes, transmitter families and locations. Separate unseen/unknown classes. Score with macro-averaged event metrics as well as per-condition breakdowns.

**Minimum exit evidence:** reproducible fixture SHA256, config commit, source decoder validity, fixed random seeds, confusion matrix by event type, sample-index timing, logs, and result table. **Go** only if at least one meaningful metric improves without unacceptable regression in others; improvement threshold to be agreed *before* observing outcomes.

## Experiment B — RF health explanations and smart capture
**Question:** Can receiver diagnostic states help explain anomaly detections without concealing true external RF anomalies?

Inject synthetic DC, gain shifts, known clipping, missing sample sections and scheduler drops; compare raw detector vs context-enhanced explanations. Record explanation recall, unsupported-cause rate, false certainty, IQ window bytes recovered, missing pretrigger state, queue-drop counts and receiver continuity. No phantom `loss=0` if counters do not exist.

**Failure gate:** feature pipeline blocking original acquisition or unaccounted IQ loss means FAIL regardless of classifier accuracy. Storage policy must cap event count/bytes per hour and preserve user consent settings.

## Experiment C — small ML versus no-ML baseline
**Question:** Is an INT8 model *actually* better than median/MAD + simple statistical classifier for difficult patterns?

Use matched features and held-out tests; train a small logistic/tree/MLP plus a model-free baseline, report model SHA, framework and quantization metadata. Require calibration analysis (reliability diagrams, ECE or Brier where appropriate), abstention/unknown threshold, open-set behavior, model drift and adverse SNR effects. Accuracy alone is insufficient; compare macro-F1, unknown recall, false alarm per hour, p50/p95/p99 CPU/inference latency, PSS, energy with named measurement instrument if possible.

**Gate:** if measured improvement is not repeatable across unseen hardware/sites, keep the simpler implementation.

## Experiment D — side-channel FPGA proof (conditional)
On verified exact XC7Z020 board, after backup/recovery and explicit separate hardware authorization, simulate an input-valid mirror and 32/64-bit accumulators. Test RTL output against host fixed-point golden vectors. Compare *full* default RX1/RX2 native IQ before/after FPGA modification; test reset/CDC, FIFO-full, overflows, retune epochs, bitstream SHA, WNS, resource delta (LUT, FF, DSP, BRAM), clock rates, IRQ burden, thermal and power. The native IIO path must remain bit-exact where specified. Negative/unknown data must remain unknown.

**Gate:** positive *post-route* timing margin on exact build, maintained IIO compatibility, 24-hour soak for any continuous claim, and no uncategorized IQ discontinuity. No assumption that FINN supports Fishball as a turnkey shell.

## Experiment E — protocol-verified reception feedback (optional)
Replay same IQ input through alternative software settings and score CRC/FEC-qualified frames and published decoder metrics. For RF gain changes, replay is insufficient—require a controlled physical test with matched independent conditions and documented receiver ownership. Use paired, grouped statistics, not cherry-picked examples. Reject settings that sacrifice overall valid frames to improve a visually appealing SNR proxy.

## Artifact contract
`experiment_id`, sample format + true ADC bits, source firmware/PL/receiver revision, data SHA256, known signal and annotation basis, source_epoch, sample-rate and center-frequency provenance, timebase validity, code commit, model SHA, test group split, full command, environment versions, measured counters, outcome, error bars, reason for exclusion. Public report carries no credentials/private identifiers and does not embed raw third-party RF transmissions without permission.

## How the next agent runs/validates in the owner environment
1. Fetch exact OrcPluto integration branch; read `PROJECT_TRUTH.md`, `ROADMAP.md`, `research/agent2/README.md`, and `docs/architecture/EDGE_AI_INTEGRATION.md`.
2. Run `python experiments/edge-detector/run_tests.py` *from the intended working directory*, inspect `edge_detector_test.log` saved there and `edge_detector_test_artifacts/`. That command is existing project documentation [P02][P03]; this package did not run it.
3. Build stand-alone A/B evaluation harness or bring host fixtures in a separate branch; save new logs in the launch directory; publish hashes, splits and a reproducible results table.
4. Only after off-target gates: perform read-only exact-device inventory and offline backup; seek distinct permission for hardware modifications/boot/FPGA/TX (RX-first). No claims until actual measurement results are attached.
