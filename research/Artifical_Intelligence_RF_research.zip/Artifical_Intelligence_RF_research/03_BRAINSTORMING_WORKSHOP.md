# Brainstorming record — original workshop expanded into testable hypotheses

**Position:** AI is a means, not the product. Start with small features, truthful explanations and testable performance; only accelerate hardware paths that exhibit real bottlenecks. Difficulty and value rankings below are *planning judgments*, not measured facts.

## 1. Spectrum Memory (highest first-prototype priority)
**User story:** “This frequency became unusually active compared with the last few days under comparable settings.”
**Easy implementation:** rolling median and robust dispersion (MAD) per frequency bin or frequency cluster, plus short/long exponential averages; store state by receiver/gain/rate/filter/site/time-validity configuration. Cold-start and reset semantics are mandatory. Hysteresis, minimum burst width and baseline-poisoning controls prevent constantly moving thresholds.
**Orc twist:** track *what changed* (frequency, duration, spectral flatness, activity cadence) and preserve the previous baseline/model version with each event. **Risk:** learned “normal” can normalize a persistent source; report absolute threshold events separately.

## 2. RF event fingerprints — morphology rather than false certainty
**User story:** “This burst looks similar to the pattern seen yesterday.”
**Easy implementation:** characterize centroid, occupied bandwidth, kurtosis/flatness, hop slope, duration, duty cycle, repetition interval, peak-to-noise ratio and amplitude envelope. Match time-series descriptors with simple distance and confidence interval. Label `morphology_match`, never real identity.
**Orc twist:** recurring cluster IDs and short event histories without raw-IQ retention. **Risk:** receiver settings and propagation distort features; identical fingerprints do not prove same emitter.

## 3. Receiver-health-aware anomaly explanations
**User story:** “This spike might be receiver overload, not a hostile signal.”
**Easy implementation:** correlate RF change with overrange/clipping, DC-bin peaks, gain switches, LO retunes, dropped samples, USB errors and filtering/decimator resets. Source-specific counters are `not_measured` if unavailable.
**Orc twist:** show a competing set of explanations with supporting measurements, not a single magic cause. **Risk:** a concurrent hardware anomaly doesn't rule out external interference.

## 4. AI-assisted reception (closed-loop but evidence-gated)
**User story:** “The recommended filter improved valid packet recovery.”
**Easy implementation:** offline IQ replay or a controlled randomized A/B procedure using objective metrics (valid CRC frames, error-correcting-code correction counts, audio distortion proxy, demod SNR where applicable). Test one setting at a time; never silently retune another client's receiver.
**Orc twist:** associate each recommendation with before/after evidence and confidence intervals. **Risk:** changing live traffic makes naive A/B comparisons meaningless.

## 5. Interference morphology classifier
**User story:** “Likely narrowband interferer / broadband occupancy / swept-frequency energy.”
**Easy implementation:** rule-based classes first, then compare small tree or quantized feature MLP on same inputs.
**Orc twist:** `source_intent=unknown`; no inference of a jammer from energetic spectral shape alone. **Risk:** poorly calibrated classes overfit controlled synthetic examples.

## 6. Smart capture with a tiny evidence budget
**User story:** “Save only the most informative 100 ms around unexpected activity.”
**Easy implementation:** bounded post-trigger capture, pretrigger ring only if reliable resource budget, metadata-only fallback, explicit truncation/loss flags.
**Orc twist:** prioritize rare/novel events, de-duplicate by cluster and cap retention. **Risk:** event-trigger latency, bandwidth pressure and privacy of captured signals.

## 7. Cooperative RF intelligence across nodes
**User story:** “Two independent receivers saw a related event.”
**Easy implementation:** compare coarse event times/frequency and confidence; share only metadata initially.
**Orc twist:** cross-location consensus that *separates local device artifacts from RF events*. **Risk:** unsynchronized clocks, shared infrastructure and antenna effects; never assert geolocation without proper calibration.

## 8. Time-aware spectrogram sequences
**User story:** “A hopping or pulsed signal is detectable even though every single FFT frame looks innocent.”
**Easy implementation:** retain only a bounded multi-frame feature history; HMM/change-point or sequence-distance baseline before GRU/temporal CNN.
**Orc twist:** report event recurrence, chirp slope and dwell distributions. **Risk:** CPU/DRAM growth and high event false-positive rate.

## 9. Contextual scan scheduling
**User story:** “Prioritize frequencies with recent meaningful activity.”
**Easy implementation:** schedule scan dwell by evidence-driven activity history with periodic exploration of neglected channels.
**Orc twist:** transparent explanations and starvation ceiling. **Risk:** tuner ownership, missed brief bursts, feedback loops.

## 10. Self-calibration and transfer learning
**User story:** “Works across device/gain/antenna changes without silently miscalibrating.”
**Easy implementation:** device-specific feature normalization and site/day held-out evaluation. Retraining occurs off-device with versioned models.
**Orc twist:** measured compatibility score for each model/receiver pair. **Risk:** datasets can embed hardware fingerprints instead of RF physics.

## 11. Explainable signal discovery
**User story:** “Show why the radio thinks a burst might be FSK, while saying it hasn't decoded anything.”
**Easy implementation:** pipeline of energy detection → candidate morphology → optional modulation family probability → validated sync/FEC/CRC *only when available*.
**Orc twist:** four distinct evidence levels, with an explicit `unknown` class. **Risk:** brand damage from presenting candidate labels as decoded fact.

## 12. FPGA TinyAI as an optimization, not the initial milestone
**User story:** “Do the same feature extraction at lower CPU overhead without losing IQ.”
**Easy implementation:** passive sample-valid counters and power; next fixed-point FFT/feature FIFO. Only after that explore a quantized MLP with FINN/hls4ml.
**Orc twist:** identical golden test vectors across C++/ARM/RTL and visible feature drop counters. **Risk:** near-critical PL timing and custom Zynq-7000 integration.

## Qualitative opportunity comparison (planning estimates)
| Idea | First prototype effort | User differentiation | Hardware coupling | Recommended order |
|---|---|---|---|---|
| Spectrum memory | Low | High | Low | 1 |
| Receiver-health explanations | Low/Medium | High | Medium | 2 |
| Event fingerprints | Low/Medium | High | Low | 3 |
| Smart capture | Medium | High | Medium | 4 |
| Offline reception A/B | Medium | Very high | Medium | 5 |
| Temporal signatures | Medium | High | Medium | 6 |
| Modulation family ML | Medium/High | Medium | Low/Medium | 7 |
| Cooperative intelligence | High | High | High | 8 |
| FPGA feature accelerator | High | High | High | After measured need |
| Full FPGA quantized classifier | Very high | Uncertain until tested | Very high | Last |

**Decision:** first three ideas share one common feature schema and offline replay harness. Treat them as ONE bounded experimental program, not three firmware projects.
