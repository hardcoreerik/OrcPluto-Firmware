# Platform feasibility, limits and comparison

## Zynq-7020 + AD9361 / OrcPluto candidate
**PUBLISHED / PROJECT_RECORDED:** OrcPluto Fishball/PlutoSky R1 project research identifies candidate XC7Z020 with a physical AD9361, dual Cortex-A9 and 7-series fabric. Exact owner-unit identity remains unverified per the integration truth snapshot [P01][P04]. AMD XC7Z020 nominal resources include 53,200 LUTs, 220 DSP48 and roughly 4.9 Mbit BRAM, but these are **device totals**, not free resources [S08][P04]. Existing Fishball R1 public-resource data in project docs reports approximately 94/220 DSP and 12,521 LUTs for a symmetric 2RX FIR configuration, with a very small +0.215 ns timing margin in that *public build*. Do not treat this as measured on the owner's board [P04][P05].

**Bandwidth arithmetic only:** CS16LE IQ is 4 bytes per complex sample per RX: at 2.4 MS/s → 9.6 MB/s; at 5 MS/s → 20 MB/s; at 10 MS/s → 40 MB/s. This is input payload, not demonstrated transport, continuous disk throughput or FPGA headroom [P01]. The AD9361's true converter bits and sign extension require recording with each fixture.

**Easy path:** ARM offline/low-cadence classifier; small feature queues, bounded CPU and memory. **Hard path:** PL signal-valid tap and optional IP/AXI/CDC clock-bridging without altering original receiver. Never flash an arbitrary PYNQ bitstream onto Fishball or assume stock Pluto SD/QSPI recovery methods are safe.

## FINN and hls4ml
AMD's FINN can emit generic Vivado IPI streaming components but officially retired turnkey PYNQ-Z1/Z2 support after switching to Vivado 2024.2. XC7Z020 may still be used with **manual IP integration, custom Linux driver, DMA wiring, and validated Vivado flow** [S03]. hls4ml can generate HLS from selected models, but support and synthesis require matching backend/tool versions; this is not automatic deployment on the target [S07]. The best initial FPGA optimization may be log-power and event-power counters, not a NN.

## ESP32-P4 (future port, no OrcSDR files touched)
Official Espressif ESP-DL documentation supports ESP32-P4 and quantized operators, and ESP-VISION exposes both ESP-DL and TFLite Micro inference paths [S04][S05]. These are **framework capabilities**, not guarantees that a specific RF feature model runs in real time alongside an SDR on the target. A subsequent product may reuse the same normalized feature records and model evaluation suite without sharing firmware code in this research deliverable.

## Host GPU / workstation
Use desktop training/benchmarking for dataset augmentation, model quantization, grouped validation and golden vectors. Host high accuracy does not establish target feasibility. All architecture rows must state exact memory and power instruments before any energy claims.

## Suggested escalation thresholds (engineering decisions, not measurements)
- Keep **statistics-only** if it meets event reliability at the desired output cadence.
- Choose **ARM INT8** only if it adds repeatable held-out value vs the simple detector at acceptable p99.
- Choose **PL features** only if CPU usage, tail latency or sample-loss pressure justifies them, with proven timing budget and IQ integrity.
- Choose **PL QNN** only if feature-stage acceleration is insufficient and quantized model benefits survive fixed-point equivalence tests.
