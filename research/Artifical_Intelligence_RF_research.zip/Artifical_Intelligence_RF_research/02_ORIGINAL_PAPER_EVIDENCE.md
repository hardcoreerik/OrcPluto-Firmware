# Source-critical review of the motivating paper

## Citation and verifiable publication
Muhammad Inam ul Haq et al., “AI-Enhanced FPGA-Based Software Defined Radio for Real-Time Spectrum Sensing and Adaptive Jamming Mitigation,” *Journal of Signal Processing Systems*, volume 98, article 53 (2026), published **2026-10-19**, DOI `10.1007/s11265-026-02026-4` [S01]. Public full text at https://link.springer.com/article/10.1007/s11265-026-02026-4 . This packet paraphrases rather than reproduces the paper.

## Claims faithfully attributed to the *paper* (not our tests)
| Paper value | What it means | Critical qualifier |
| --- | --- | --- |
| 2048-point FFT | FFT features of a sample window | FFT length is not number of simultaneously isolated signals or processing threads. |
| Normalized log-power features | Spectral magnitude-based representation | Feature calibration and windowing determine comparability. |
| INT4/INT8 QNN on programmable logic | Reduced-precision neural inference pipeline | Toolchain, resource utilization and topology are paper-specific. |
| 2.1 ms end-to-end latency | Authors' reported default-configuration latency | Not a universal limit or our AD9361 data-to-user latency. |
| 94.5% classification accuracy @ +5 dB SNR | Authors' reported modulation-classification evaluation | Not 94.5% jammer mitigation, nor out-of-distribution accuracy. |
| 96.3% jammer detection at false-alarm probability 0.05 | One operating point on reported ROC analysis | Does **not** imply zero false positives or correct causal attribution. |
| ~1.8 mJ per inference | Authors' reported energy per classifier inference | Cannot generalize to our radio's total energy or 24-hour duty cycle. |

## Paper architecture
Sample stream from an SDR front end, such as Pluto or USRP → AXI-DMA → 2048 FFT → normalization / log-power / statistics → quantized NN logic → host-side policy/control. PYNQ-Z2 uses Zynq-7020 dual ARM A9 plus programmable logic [S01]. Paper emphasizes deterministic PL processing and low host-CPU intervention.

## Key limitations acknowledged in the paper
The paper's Discussion reports a fixed set of modulation and jammer profiles; adaptive or unseen jammer patterns may be missed; a single-channel prototype; evaluation primarily on synthetic and controlled OTA data; field tests and stronger adversarial/security validation still needed [S01]. Its contribution is system/architecture integration rather than a genuinely novel learning algorithm. The supplied abstract's security language should not be read as an independently proven guarantee against side channels.

## Transferability to OrcPluto
Same broad FPGA family does not equal same fabric headroom, IP map, clocks, power instrumentation, or working toolchain. OrcPluto's Fishball/PlutoSky R1 candidate includes a distinct AD9361 receive chain and board boot/recovery constraints [P01][P02]. Real hardware identity and timing margin remain to be verified. The paper does *not* establish a drop-in bitstream, source compatibility, an OrcStream event format, or safe transmit-side control.

## Research questions the paper leaves open
- Can a context-conditioned adaptive baseline beat an energy detector and CFAR on *unseen environments*?
- Can a sequence of short feature frames detect hopping/swept patterns earlier than independent 2048-bin decisions?
- Can receiver-health counters explain false positives and prevent erroneous “jammer” labels?
- Can protocol-validated feedback improve reception against frozen recording test cases, not changing live comparisons?
- Does a small 8-bit feature MLP add enough value to justify inference time and validation burden over robust statistics?

Reference [S01].
